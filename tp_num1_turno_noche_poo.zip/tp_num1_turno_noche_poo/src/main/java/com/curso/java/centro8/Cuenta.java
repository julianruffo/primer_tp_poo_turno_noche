package com.curso.java.centro8;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@AllArgsConstructor 
@ToString 
public abstract class Cuenta {
private int numeroCuenta;
private Cliente cliente;
private double saldo;

public abstract void depositarEfectivo(double monto);

public abstract void extraerEfectivo(double monto);


}
