package com.curso.java.centro8;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter 
@Setter 
@ToString 
public class Cheque {
    private double monto;
    private String bancoEmisor;
    private LocalDate fechaPago;

}
