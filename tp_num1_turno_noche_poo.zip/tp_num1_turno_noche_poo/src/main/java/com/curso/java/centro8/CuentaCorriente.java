package com.curso.java.centro8;

public class CuentaCorriente extends Cuenta {
 private double montoAutorizadoDescubierto;

 public CuentaCorriente(int numeroCuenta, Cliente cliente, double saldo, double montoAutorizadoDescubierto) {
  super(numeroCuenta, cliente, saldo);
  this.montoAutorizadoDescubierto = montoAutorizadoDescubierto;
 }

 @Override
 public void depositarEfectivo(double monto) {
  setSaldo(getSaldo() + monto);
 }

 @Override
 public void extraerEfectivo(double monto) {
  if (getSaldo() + montoAutorizadoDescubierto >= monto) {
   setSaldo(getSaldo() - monto);
  } else {
   System.out.println("No se puede extraer el monto solicitado. Saldo insuficiente.");
  }
 }

 public void depositarCheque(Cheque cheque) {
  setSaldo(getSaldo() + cheque.getMonto());
 }

 
}
