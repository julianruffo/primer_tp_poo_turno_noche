package com.curso.java.centro8;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString (callSuper = true)
public class CajaDeAhorro extends Cuenta {
 private double tasaInteres;

 public CajaDeAhorro(int numeroCuenta, Cliente cliente, double saldo, double tasaInteres) {
  super(numeroCuenta, cliente, saldo);
  this.tasaInteres = tasaInteres;
 }

 @Override
 public void depositarEfectivo(double monto) {
  setSaldo(getSaldo() + monto);
 }

 @Override
 public void extraerEfectivo(double monto) {
  if (monto <= getSaldo()) {
   setSaldo(getSaldo() - monto);
  } else {
   System.out.println("Saldo insuficiente");
  }
 }

 public void cobrarInteres() {
  double interes = getSaldo() * tasaInteres;
  setSaldo(getSaldo() + interes);
 }

}
