package com.curso.java.centro8;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class ClienteEmpresa extends Cliente {

    private String nombreFantasia;
    private String cuit;

    public ClienteEmpresa(int id, String nombreFantasia, String cuit) {
        super(id);
        this.nombreFantasia = nombreFantasia;
        this.cuit = cuit;
    }
}
