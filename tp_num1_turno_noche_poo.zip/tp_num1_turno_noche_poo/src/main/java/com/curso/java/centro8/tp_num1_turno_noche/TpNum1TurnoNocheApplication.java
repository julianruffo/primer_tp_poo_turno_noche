package com.curso.java.centro8.tp_num1_turno_noche;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpNum1TurnoNocheApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpNum1TurnoNocheApplication.class, args);
	}

}
