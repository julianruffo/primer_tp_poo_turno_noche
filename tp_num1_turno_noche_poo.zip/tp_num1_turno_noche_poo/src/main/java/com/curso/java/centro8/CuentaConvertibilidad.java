package com.curso.java.centro8;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CuentaConvertibilidad extends CuentaCorriente {

    private double saldoDolares;

    public CuentaConvertibilidad(
            int numeroCuenta,
            ClienteEmpresa cliente,
            double saldo,
            double montoAutorizadoDescubierto,
            double saldoDolares) {

        super(numeroCuenta, cliente, saldo, montoAutorizadoDescubierto);
        this.saldoDolares = saldoDolares;
    }

    public void depositarEfectivoDolares(double monto) {
        this.saldoDolares += monto;
    }

    public void extraerEfectivoDolares(double monto) {
        this.saldoDolares -= monto;
    }

    public void convertirPesosADolares(double monto, double tipoCambio) {

        if (monto <= getSaldo()) {

            double montoDolares = monto / tipoCambio;

            extraerEfectivo(monto);

            depositarEfectivoDolares(montoDolares);

        } else {

            System.out.println(
                    "No hay suficiente saldo en pesos para convertir a dólares."
            );
        }
    }

    public void convertirDolaresAPesos(double monto, double tipoCambio) {

        if (monto <= getSaldoDolares()) {

            double montoPesos = monto * tipoCambio;

            extraerEfectivoDolares(monto);

            depositarEfectivo(montoPesos);

        } else {

            System.out.println(
                    "No hay suficiente saldo en dólares para convertir a pesos."
            );
        }
    }
}