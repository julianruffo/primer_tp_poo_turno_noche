package com.curso.java.centro8.tests;

import java.time.LocalDate;

import com.curso.java.centro8.Cheque;
import com.curso.java.centro8.ClienteEmpresa;
import com.curso.java.centro8.CuentaCorriente;

public class TestCheque {

    public static void main(String[] args) {

        ClienteEmpresa empresa =
                new ClienteEmpresa(1, "Tech S.A.", "30519190989");

        CuentaCorriente cuenta1 =
                new CuentaCorriente(2002, empresa, 10000.0, 5000.0);

        Cheque cheque1 = new Cheque();
        cheque1.setMonto(5000.0);
        cheque1.setBancoEmisor("Banco Nación");
        cheque1.setFechaPago(LocalDate.of(2026, 9, 28));

        System.out.println("Saldo antes del cheque: " + cuenta1.getSaldo());

        cuenta1.depositarCheque(cheque1);

        System.out.println("Saldo después del cheque: " + cuenta1.getSaldo());
        System.out.println("Monto del cheque: " + cheque1.getMonto());
        System.out.println("Banco emisor: " + cheque1.getBancoEmisor());
        System.out.println("Fecha de pago: " + cheque1.getFechaPago());
    }
}
