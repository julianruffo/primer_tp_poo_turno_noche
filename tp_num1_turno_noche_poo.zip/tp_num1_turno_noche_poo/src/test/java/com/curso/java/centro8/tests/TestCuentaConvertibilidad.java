package com.curso.java.centro8.tests;

import com.curso.java.centro8.ClienteEmpresa;
import com.curso.java.centro8.CuentaConvertibilidad;

public class TestCuentaConvertibilidad {

    public static void main(String[] args) {

        ClienteEmpresa empresa =
                new ClienteEmpresa(1, "Tech S.A.", "30519190989");

        CuentaConvertibilidad cuenta1 =
                new CuentaConvertibilidad(1003,empresa,10000.0,5000.0,1000.0
                );

        System.out.println("Saldo inicial en pesos: " + cuenta1.getSaldo());

        System.out.println("Saldo inicial en dólares: "
                + cuenta1.getSaldoDolares());


        // DEPOSITAMOS 500 DÓLARES
        cuenta1.depositarEfectivoDolares(500);

        System.out.println("Saldo en dólares después de depositar: "
                + cuenta1.getSaldoDolares());


        // EXTRAEMOS 500 DÓLARES
        cuenta1.extraerEfectivoDolares(500);

        System.out.println("Saldo en dólares después de extraer: "
                + cuenta1.getSaldoDolares());


        // CONVERTIMOS 1000 PESOS A DÓLARES
        cuenta1.convertirPesosADolares(1000, 1530);

        System.out.println("Saldo en pesos después de convertir: "
                + cuenta1.getSaldo());

        System.out.println("Saldo en dólares después de convertir: "
                + cuenta1.getSaldoDolares());


        // CONVERTIMOS 200 DÓLARES A PESOS
        cuenta1.convertirDolaresAPesos(200, 1450);

        System.out.println("Saldo en pesos después de convertir dólares a pesos: "
                + cuenta1.getSaldo());

        System.out.println("Saldo en dólares final: "
                + cuenta1.getSaldoDolares());
    }
}