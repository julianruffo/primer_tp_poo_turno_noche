package com.curso.java.centro8.tests;

import java.time.LocalDate;

import com.curso.java.centro8.Cheque;
import com.curso.java.centro8.ClienteEmpresa;
import com.curso.java.centro8.CuentaCorriente;

public class TestCuentaCorriente {
    public static void main(String[] args) {
       ClienteEmpresa empresa = new ClienteEmpresa(1, "Tech S.A.", "30519190989");

       CuentaCorriente cuenta1 = new CuentaCorriente(2002, empresa, 10000.0, 5000.0);
     
       System.out.println("Saldo inicial: " + cuenta1.getSaldo());

       cuenta1.extraerEfectivo(13000);
       System.out.println("Saldo después de extraer: " + cuenta1.getSaldo());

       cuenta1.extraerEfectivo(16000);
       System.out.println("Saldo después de extraer: " + cuenta1.getSaldo());

       cuenta1.depositarEfectivo(16000);
       System.out.println("Saldo después de depositar: " + cuenta1.getSaldo());

                    // Creamos el cheque
        Cheque cheque1 = new Cheque();

        // Cargamos los datos del cheque
        cheque1.setMonto(5000.0);
        cheque1.setBancoEmisor("Banco Nación");
        cheque1.setFechaPago(LocalDate.of(2026, 9, 28));

        // Mostramos saldo antes de depositar el cheque
        System.out.println(
                "Saldo antes del cheque: " + cuenta1.getSaldo()
        );

        // Depositamos el cheque
        cuenta1.depositarCheque(cheque1);

        // Mostramos los datos del cheque
        System.out.println("Monto del cheque: " + cheque1.getMonto());
        System.out.println("Banco emisor: " + cheque1.getBancoEmisor());
        System.out.println("Fecha de pago: " + cheque1.getFechaPago());

            // Mostramos saldo después
        System.out.println(
                "Saldo después del cheque: " + cuenta1.getSaldo()
        );




    }


    

}
